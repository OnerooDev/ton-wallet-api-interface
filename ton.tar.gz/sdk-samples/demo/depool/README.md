# Getting information from DePool with NodeJS

In this example we run get methods of an existing [DePool](https://github.com/tonlabs/ton-labs-contracts/blob/master/solidity/depool/DePool.sol) from [main.ton.live](main.ton.live). If you want to connect to another DePool, choose from сatalog of DePools [https://ton.live/dePools](https://ton.live/dePools).

## Install packages & run:

```sh
npm i
npm start
```
