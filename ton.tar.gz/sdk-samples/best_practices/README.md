# Best practices

In this folder we will post samples demonstating best practices of implementation of some use cases


**Need info about best practices for your use-case? Get quick help in our channel:**

[![Channel on Telegram](https://img.shields.io/badge/chat-on%20telegram-9cf.svg)](https://t.me/ton_sdk) 
