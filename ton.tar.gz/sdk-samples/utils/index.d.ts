export declare function loadContract(relativePath: string): { abi: any, tvc?: string };
