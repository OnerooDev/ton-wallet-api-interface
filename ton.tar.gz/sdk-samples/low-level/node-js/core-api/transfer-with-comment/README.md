# NodeJS  transfer tokens with comment

In this example we demostrate how to transfer tokens from one contract to another with comment/

## Prerequisite

* Node.js >= [12.x installed](https://nodejs.org)


## Install packages & run:

```sh
npm install
node index.js
```
