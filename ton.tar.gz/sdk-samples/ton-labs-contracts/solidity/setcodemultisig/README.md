# Setcode Multisignature wallet
SetcodeMultisigWallet - multisignature wallet with setcode.

More information about multisignature wallet can be read in [SafeMultisig readme](https://github.com/tonlabs/ton-labs-contracts/tree/master/solidity/safemultisig/README.md)