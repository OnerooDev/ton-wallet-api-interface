# NodeJS SDK cache using example

In this example we use [ton-client-js](https://github.com/tonlabs/ton-client-js) to call `tvm.run_tvm` method using cached account BOC.

## Prerequisite

* Node.js >= [12.x installed](https://nodejs.org)


## Install packages & run:

```sh
npm i
npm start
```
